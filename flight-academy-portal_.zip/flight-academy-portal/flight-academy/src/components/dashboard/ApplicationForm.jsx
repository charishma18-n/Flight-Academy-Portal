import { useState } from 'react';
import { useApp } from '../../context/AppContext';
import useForm from '../../hooks/useForm';
import { COURSES, ELIGIBILITY } from '../../data/constants';
import { validateEligibility, validatePersonalInfo } from '../../utils/helpers';

const EDUCATION_OPTIONS = [
  { value: '', label: '— Select your qualification —' },
  { value: '10+2 (Science) – Physics, Chemistry, Mathematics', label: '10+2 (Science) – Physics, Chemistry, Mathematics' },
  { value: '10+2 (Science) – Physics, Mathematics, Computer Science', label: '10+2 (Science) – Physics, Mathematics, Computer Science' },
  { value: 'B.Sc. in Aviation', label: 'B.Sc. in Aviation' },
  { value: 'B.Sc. in Physics / Mathematics', label: 'B.Sc. in Physics / Mathematics' },
  { value: 'B.Tech / B.E. (Aerospace Engineering)', label: 'B.Tech / B.E. (Aerospace Engineering)' },
  { value: 'B.Tech / B.E. (Mechanical / EEE / ECE)', label: 'B.Tech / B.E. (Mechanical / EEE / ECE)' },
  { value: 'B.Tech / B.E. (Other Engineering)', label: 'B.Tech / B.E. (Other Engineering)' },
  { value: 'Diploma in Aviation / Aeronautics', label: 'Diploma in Aviation / Aeronautics' },
  { value: 'Graduate – Other Stream (with Physics & Maths)', label: 'Graduate – Other Stream (with Physics & Maths)' },
];

function FieldHint({ msg }) {
  if (!msg) return null;
  return (
    <div style={{ fontSize: '0.78rem', color: 'var(--red)', marginTop: -8, marginBottom: 10, display: 'flex', alignItems: 'center', gap: 4 }}>
      <i className="ti ti-alert-circle" style={{ fontSize: 13 }} />{msg}
    </div>
  );
}

export default function ApplicationForm({ onTabChange }) {
  const { user, myApplication, submitApplication } = useApp();
  const [step, setStep] = useState(1);

  const { values, error, set, setError } = useForm({
    age: '', education: '', medicalCert: '', flightHours: '',
    phone: '', address: '', course: '',
  });

  const hints = {
    age:         values.age && (parseInt(values.age) < 17 || parseInt(values.age) > 35)
                   ? 'Age must be between 17 and 35' : '',
    flightHours: values.flightHours && parseInt(values.flightHours) < 40
                   ? 'Minimum 40 flight hours required' : '',
    phone:       values.phone && values.phone.replace(/[\s\-+()]/g,'').length > 4
                   && !/^(\+?91)?[6-9]\d{9}$/.test(values.phone.replace(/[\s\-+()]/g,''))
                   ? 'Enter a valid 10-digit mobile number starting with 6–9' : '',
    address:     values.address && values.address.trim().length > 3
                   && (/^(.)\1{3,}$/.test(values.address.replace(/\s/g,'')) || /^\d+$/.test(values.address.trim()))
                   ? 'Please enter a valid address' : '',
  };

  if (myApplication && step !== 4) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
        <i className="ti ti-circle-check" style={{ fontSize: 56, color: 'var(--green)', display: 'block', marginBottom: '1rem' }} />
        <h3 style={{ color: 'var(--green)', marginBottom: 8 }}>Application Already Submitted</h3>
        <p style={{ color: 'var(--gray-600)' }}>Your application ID is <strong>{myApplication.id}</strong>.</p>
        <button className="btn btn-primary" style={{ marginTop: '1rem' }} onClick={() => onTabChange('status')}>Track Status</button>
      </div>
    );
  }

  if (step === 4) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
        <i className="ti ti-circle-check" style={{ fontSize: 56, color: 'var(--green)', display: 'block', marginBottom: '1rem' }} />
        <h3 style={{ color: 'var(--green)', marginBottom: 8 }}>Application Submitted!</h3>
        <p style={{ color: 'var(--gray-600)', marginBottom: '1.5rem' }}>We will review your application within 5 business days.</p>
        <button className="btn btn-primary" onClick={() => onTabChange('status')}>Track Application Status</button>
      </div>
    );
  }

  function goStep2() {
    const err = validateEligibility(values);
    if (err) { setError(err); return; }
    setError(''); setStep(2);
  }

  function goStep3() {
    const err = validatePersonalInfo(values);
    if (err) { setError(err); return; }
    setError(''); setStep(3);
  }

  function handleSubmit() {
    submitApplication({
      age: values.age, education: values.education,
      medicalCert: values.medicalCert, flightHours: values.flightHours,
      phone: values.phone, address: values.address, course: values.course,
    });
    setStep(4);
  }

  const stepLabels = ['Eligibility Check', 'Personal Details', 'Review & Submit'];

  return (
    <div className="card">
      <h2 style={{ margin: '0 0 0.5rem', fontWeight: 400 }}>Admission Application</h2>
      <p style={{ color: 'var(--gray-600)', marginBottom: '2rem', fontSize: '0.9rem' }}>
        Complete all sections carefully. All fields are verified before submission.
      </p>

      {/* Step bar */}
      <div className="step-bar">
        {stepLabels.map((label, i) => (
          <div key={i} className={`step-item ${step > i + 1 ? 'done' : step === i + 1 ? 'active' : ''}`}>
            <span className={`step-dot ${step > i + 1 ? 'done' : step === i + 1 ? 'active' : ''}`}>{i + 1}</span>
            {label}
          </div>
        ))}
      </div>

      {/* ── STEP 1: Eligibility ── */}
      {step === 1 && (
        <div>
          <div className="alert alert-info" style={{ marginBottom: '1.5rem' }}>
            <i className="ti ti-info-circle" />
            <span>
              <strong>Eligibility criteria:</strong>&nbsp;
              Age 17–35 &nbsp;|&nbsp; Min {ELIGIBILITY.minFlightHours} flight hours &nbsp;|&nbsp;
              Class 1 or 2 Medical &nbsp;|&nbsp; 10+2 with Physics &amp; Maths (or equivalent)
            </span>
          </div>

          {/* Age */}
          <div className="form-group">
            <label className="form-label">Age <span style={{ color: 'var(--red)' }}>*</span></label>
            <div style={{ position: 'relative' }}>
              <i className="ti ti-calendar" style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)', fontSize: 16, pointerEvents: 'none' }} />
              <input
                type="number" min="17" max="35"
                className="form-input"
                value={values.age}
                onChange={e => set('age', e.target.value)}
                placeholder="Your age"
              />
            </div>
            <FieldHint msg={hints.age} />
          </div>

          {/* Education — dropdown */}
          <div className="form-group">
            <label className="form-label">Educational Qualification <span style={{ color: 'var(--red)' }}>*</span></label>
            <div style={{ position: 'relative' }}>
              <i className="ti ti-school" style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)', fontSize: 16, pointerEvents: 'none', zIndex: 1 }} />
              <select
                className="form-select"
                style={{ paddingLeft: '2.2rem' }}
                value={values.education}
                onChange={e => set('education', e.target.value)}
              >
                {EDUCATION_OPTIONS.map(opt => (
                  <option key={opt.value} value={opt.value}>{opt.label}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Flight Hours */}
          <div className="form-group">
            <label className="form-label">Total Flight Hours <span style={{ color: 'var(--red)' }}>*</span></label>
            <div style={{ position: 'relative' }}>
              <i className="ti ti-plane" style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)', fontSize: 16, pointerEvents: 'none' }} />
              <input
                type="number" min="0" max="50000"
                className="form-input"
                value={values.flightHours}
                onChange={e => set('flightHours', e.target.value)}
                placeholder="Minimum 40 hours required"
              />
            </div>
            <FieldHint msg={hints.flightHours} />
          </div>

          {/* Medical Cert */}
          <div className="form-group">
            <label className="form-label">Medical Certificate <span style={{ color: 'var(--red)' }}>*</span></label>
            <div style={{ position: 'relative' }}>
              <i className="ti ti-stethoscope" style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)', fontSize: 16, pointerEvents: 'none', zIndex: 1 }} />
              <select
                className="form-select"
                style={{ paddingLeft: '2.2rem' }}
                value={values.medicalCert}
                onChange={e => set('medicalCert', e.target.value)}
              >
                <option value="">— Select certificate class —</option>
                <option value="Class 1">Class 1 – For Commercial Pilot License (CPL / ATPL)</option>
                <option value="Class 2">Class 2 – For Private Pilot License (PPL)</option>
              </select>
            </div>
          </div>

          {error && <div className="alert alert-error" style={{ marginBottom: '1rem' }}><i className="ti ti-alert-circle" />{error}</div>}
          <button className="btn btn-primary" onClick={goStep2}>
            <i className="ti ti-shield-check" />Check Eligibility &amp; Continue
          </button>
        </div>
      )}

      {/* ── STEP 2: Personal Info ── */}
      {step === 2 && (
        <div>
          <div className="alert alert-success" style={{ marginBottom: '1.5rem' }}>
            <i className="ti ti-circle-check" />
            Eligibility verified. Please complete your personal details accurately.
          </div>

          {/* Phone */}
          <div className="form-group">
            <label className="form-label">Mobile Number <span style={{ color: 'var(--red)' }}>*</span></label>
            <div style={{ position: 'relative' }}>
              <i className="ti ti-phone" style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)', fontSize: 16, pointerEvents: 'none' }} />
              <input
                type="tel"
                className="form-input"
                value={values.phone}
                onChange={e => set('phone', e.target.value)}
                placeholder="10-digit mobile number"
                maxLength={13}
              />
            </div>
            <FieldHint msg={hints.phone} />
          </div>

          {/* Address */}
          <div className="form-group">
            <label className="form-label">Current Address <span style={{ color: 'var(--red)' }}>*</span></label>
            <div style={{ position: 'relative' }}>
              <i className="ti ti-map-pin" style={{ position: 'absolute', left: 10, top: 14, color: 'var(--gray-400)', fontSize: 16, pointerEvents: 'none' }} />
              <textarea
                className="form-input"
                style={{ paddingLeft: '2.2rem', minHeight: 80, resize: 'vertical' }}
                value={values.address}
                onChange={e => set('address', e.target.value)}
                placeholder="Door No, Street, City, State – PIN"
                maxLength={200}
              />
            </div>
            <FieldHint msg={hints.address} />
          </div>

          {/* Course */}
          <div className="form-group">
            <label className="form-label">Course Applied For <span style={{ color: 'var(--red)' }}>*</span></label>
            <div style={{ position: 'relative' }}>
              <i className="ti ti-plane-departure" style={{ position: 'absolute', left: 10, top: '50%', transform: 'translateY(-50%)', color: 'var(--gray-400)', fontSize: 16, pointerEvents: 'none', zIndex: 1 }} />
              <select
                className="form-select"
                style={{ paddingLeft: '2.2rem' }}
                value={values.course}
                onChange={e => set('course', e.target.value)}
              >
                <option value="">— Select a course —</option>
                {COURSES.map(c => (
                  <option key={c.id} value={c.name}>{c.name} — {c.fee} ({c.duration})</option>
                ))}
              </select>
            </div>
          </div>

          {error && <div className="alert alert-error" style={{ marginBottom: '1rem' }}><i className="ti ti-alert-circle" />{error}</div>}
          <div style={{ display: 'flex', gap: '1rem' }}>
            <button className="btn btn-ghost" onClick={() => { setStep(1); setError(''); }}>
              <i className="ti ti-arrow-left" />Back
            </button>
            <button className="btn btn-primary" onClick={goStep3}>
              Continue to Review <i className="ti ti-arrow-right" />
            </button>
          </div>
        </div>
      )}

      {/* ── STEP 3: Review ── */}
      {step === 3 && (
        <div>
          <h3 style={{ fontWeight: 500, marginBottom: '1.25rem', fontSize: '1rem' }}>
            <i className="ti ti-checklist" style={{ marginRight: 6, color: 'var(--blue)' }} />
            Review Your Application
          </h3>
          <div style={{ background: '#f8faff', border: '1px solid var(--gray-200)', borderRadius: 8, padding: '1.25rem', marginBottom: '1.5rem' }}>
            {[
              ['Applicant',    user.name],
              ['Email',        user.email],
              ['Age',          `${values.age} years`],
              ['Education',    values.education],
              ['Medical Cert', values.medicalCert],
              ['Flight Hours', `${values.flightHours} hours`],
              ['Mobile',       values.phone],
              ['Address',      values.address],
              ['Course',       values.course],
            ].map(([k, v]) => (
              <div key={k} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', padding: '0.5rem 0', borderBottom: '1px solid var(--gray-200)', fontSize: '0.88rem', gap: '1rem' }}>
                <span style={{ color: 'var(--gray-600)', flexShrink: 0, minWidth: 110 }}>{k}</span>
                <span style={{ fontWeight: 500, textAlign: 'right' }}>{v}</span>
              </div>
            ))}
          </div>
          <div className="alert alert-warning" style={{ marginBottom: '1.5rem' }}>
            <i className="ti ti-info-circle" />
            By submitting, you confirm all information is accurate. You cannot edit after submission.
          </div>
          <div style={{ display: 'flex', gap: '1rem' }}>
            <button className="btn btn-ghost" onClick={() => { setStep(2); setError(''); }}>
              <i className="ti ti-arrow-left" />Edit Details
            </button>
            <button className="btn btn-success" onClick={handleSubmit}>
              <i className="ti ti-send" />Submit Application
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
