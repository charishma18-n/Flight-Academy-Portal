import { useRef } from 'react';
import { useApp } from '../../context/AppContext';
import { ELIGIBILITY } from '../../data/constants';

export default function TestScoresManager() {
  const { applications, adminSetScore } = useApp();
  const scheduled = applications.filter(a => a.testScheduled);

  return (
    <div>
      <h2 style={{ marginBottom: '1.5rem', fontWeight: 400 }}>Entrance Test Scores</h2>

      {scheduled.length === 0 && (
        <div className="card" style={{ textAlign: 'center', color: 'var(--gray-600)', padding: '3rem' }}>
          No tests have been scheduled yet.
        </div>
      )}

      {scheduled.map(a => (
        <ScoreRow key={a.id} app={a} onSave={adminSetScore} />
      ))}
    </div>
  );
}

function ScoreRow({ app, onSave }) {
  const inputRef = useRef();
  const hasScore = app.testScore !== null;
  const passed   = hasScore && parseInt(app.testScore) >= ELIGIBILITY.testPassMark;

  return (
    <div className="card" style={{ marginBottom: '1rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>

        <div>
          <div style={{ fontWeight: 600 }}>{app.name}</div>
          <div style={{ fontSize: '0.85rem', color: 'var(--gray-600)', marginTop: 3 }}>
            <i className="ti ti-calendar" style={{ marginRight: 4 }} />Test: {app.testScheduled}
          </div>
          <div style={{ fontSize: '0.85rem', color: 'var(--gray-600)' }}>
            <i className="ti ti-id-badge" style={{ marginRight: 4 }} />{app.id}
          </div>

          {hasScore && (
            <span
              className="badge"
              style={{
                marginTop: 8,
                display: 'inline-flex',
                background: passed ? 'var(--green-light)' : 'var(--red-light)',
                color:      passed ? 'var(--green)'       : 'var(--red)',
              }}
            >
              Score: {app.testScore}/100 — {passed ? 'Passed' : 'Failed'}
            </span>
          )}
        </div>

        <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
          <input
            ref={inputRef}
            type="number" min="0" max="100"
            defaultValue={app.testScore ?? ''}
            placeholder="0 – 100"
            style={{
              width: 110, padding: '0.45rem 0.75rem',
              border: '1px solid var(--gray-200)',
              borderRadius: 'var(--border-radius-sm)',
              fontSize: '0.9rem',
            }}
          />
          <button
            className="btn btn-primary"
            onClick={() => onSave(app.id, inputRef.current.value)}
            style={{ padding: '0.45rem 1rem', fontSize: '0.85rem' }}
          >
            Save Score
          </button>
        </div>
      </div>
    </div>
  );
}
