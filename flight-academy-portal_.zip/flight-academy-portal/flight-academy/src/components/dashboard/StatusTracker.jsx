import { useApp } from '../../context/AppContext';
import StatusBadge from '../common/StatusBadge';

const PROGRESS_STEPS = [
  { label: 'Application Submitted',  icon: 'ti-file-check',    doneWhen: () => true },
  {
    label: 'Documents Verified',      icon: 'ti-files',
    doneWhen: s => ['Documents Verified', 'Test Scheduled', 'Accepted', 'Waitlisted', 'Rejected'].includes(s),
  },
  {
    label: 'Test Scheduled',          icon: 'ti-calendar-check',
    doneWhen: s => ['Test Scheduled', 'Accepted', 'Waitlisted'].includes(s),
  },
  {
    label: 'Final Decision',          icon: 'ti-award',
    doneWhen: s => ['Accepted', 'Waitlisted', 'Rejected'].includes(s),
  },
];

export default function StatusTracker({ onTabChange }) {
  const { myApplication } = useApp();

  if (!myApplication) {
    return (
      <div className="card" style={{ textAlign: 'center', padding: '3rem' }}>
        <i className="ti ti-file-off" style={{ fontSize: 48, color: 'var(--gray-200)', display: 'block', marginBottom: '1rem' }} />
        <div style={{ color: 'var(--gray-600)' }}>No application found. Please submit your application first.</div>
        <button className="btn btn-primary" style={{ marginTop: '1rem' }} onClick={() => onTabChange('apply')}>
          Apply Now
        </button>
      </div>
    );
  }

  return (
    <div>
      {/* Summary card */}
      <div className="card" style={{ marginBottom: '1rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.75rem' }}>
          <div>
            <div style={{ fontSize: '0.8rem', color: 'var(--gray-600)' }}>Application ID</div>
            <div style={{ fontWeight: 700, color: 'var(--blue)', fontSize: '1.1rem' }}>{myApplication.id}</div>
          </div>
          <StatusBadge status={myApplication.status} size="large" />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '0.75rem' }}>
          {[
            ['Course',     myApplication.course || 'CPL'],
            ['Submitted',  myApplication.submittedDate],
            ['Test Date',  myApplication.testScheduled || 'Not scheduled'],
          ].map(([k, v]) => (
            <div key={k} style={{ fontSize: '0.85rem' }}>
              <div style={{ color: 'var(--gray-600)', marginBottom: 2 }}>{k}</div>
              <div style={{ fontWeight: 500 }}>{v}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Progress timeline */}
      <div className="card" style={{ marginBottom: '1rem' }}>
        <h3 style={{ fontWeight: 500, marginBottom: '1.25rem', fontSize: '1rem' }}>Application Progress</h3>
        {PROGRESS_STEPS.map((step, i) => {
          const done = step.doneWhen(myApplication.status);
          return (
            <div key={i} className="timeline-item">
              <div className={`timeline-dot ${done ? 'done' : ''}`}>
                <i className={`ti ${step.icon}`} style={{ fontSize: 18, color: done ? 'var(--green)' : 'var(--gray-400)' }} />
              </div>
              <div style={{ paddingTop: 6 }}>
                <div style={{ fontWeight: 500, color: done ? 'var(--navy)' : 'var(--gray-400)' }}>{step.label}</div>
                {done && (
                  <div style={{ fontSize: '0.78rem', color: 'var(--green)', marginTop: 2 }}>
                    <i className="ti ti-check" style={{ marginRight: 4 }} />Completed
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Notifications */}
      <div className="card">
        <h3 style={{ fontWeight: 500, marginBottom: '1rem', fontSize: '1rem' }}>All Notifications</h3>
        {[...myApplication.notifications].reverse().map((n, i) => (
          <div key={i} style={{
            padding: '0.7rem 0.9rem',
            borderLeft: '3px solid var(--blue)',
            background: '#f8faff',
            borderRadius: '0 6px 6px 0',
            marginBottom: 8,
            fontSize: '0.88rem',
            display: 'flex', gap: 8, alignItems: 'flex-start',
          }}>
            <i className="ti ti-bell" style={{ color: 'var(--blue)', marginTop: 2, flexShrink: 0 }} />
            <span>{n}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
