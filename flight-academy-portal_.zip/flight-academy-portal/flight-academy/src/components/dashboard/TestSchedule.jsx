import { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { TEST_SLOTS, ELIGIBILITY, ACADEMY } from '../../data/constants';

export default function TestSchedule() {
  const { myApplication, scheduleTest, showToast } = useApp();
  const [selected, setSelected] = useState('');

  function handleConfirm() {
    if (!selected) { showToast('Please select a time slot', 'error'); return; }
    scheduleTest(myApplication.id, selected);
    setSelected('');
  }

  // ── Already scheduled ──────────────────────────────────────
  if (myApplication?.testScheduled) {
    const score    = myApplication.testScore;
    const passed   = score !== null && parseInt(score) >= ELIGIBILITY.testPassMark;

    return (
      <div className="card">
        <h2 style={{ margin: '0 0 1.5rem', fontWeight: 400 }}>Entrance Test</h2>

        {/* Confirmed slot */}
        <div style={{
          background: 'var(--green-light)', border: '1px solid var(--green-mid)',
          borderRadius: 'var(--border-radius-lg)', padding: '1.5rem', marginBottom: '1.5rem',
        }}>
          <i className="ti ti-calendar-check" style={{ fontSize: 32, color: 'var(--green)', display: 'block', marginBottom: '0.75rem' }} />
          <div style={{ fontWeight: 600, color: 'var(--green)', marginBottom: 4 }}>Test Scheduled</div>
          <div style={{ color: 'var(--green)', fontSize: '1.1rem' }}>{myApplication.testScheduled}</div>
          <div style={{ color: 'var(--gray-800)', fontSize: '0.85rem', marginTop: 8 }}>
            <i className="ti ti-map-pin" style={{ marginRight: 6 }} />
            {ACADEMY.venue}
          </div>
        </div>

        {/* What to bring */}
        <div style={{ background: '#f8faff', borderRadius: 'var(--border-radius-md)', padding: '1rem', marginBottom: '1.5rem' }}>
          <div style={{ fontWeight: 600, marginBottom: 8 }}>What to bring</div>
          {[
            'Valid Photo ID (Aadhaar / Passport)',
            'Admit card (download below)',
            'Two passport-size photographs',
            'Stationery (pen, pencil, eraser)',
          ].map((item, i) => (
            <div key={i} style={{ fontSize: '0.88rem', color: 'var(--gray-800)', marginBottom: 4 }}>
              <i className="ti ti-arrow-right" style={{ marginRight: 6, color: 'var(--blue)' }} />
              {item}
            </div>
          ))}
          <button
            className="btn btn-primary"
            style={{ marginTop: '1rem', fontSize: '0.85rem' }}
            onClick={() => showToast('Admit card downloaded')}
          >
            <i className="ti ti-download" />Download Admit Card
          </button>
        </div>

        {/* Score card */}
        {score !== null && (
          <div style={{
            borderRadius: 'var(--border-radius-lg)', padding: '1.5rem', textAlign: 'center',
            background: passed ? 'var(--green-light)' : 'var(--red-light)',
          }}>
            <div style={{ fontSize: '0.85rem', color: 'var(--gray-600)', marginBottom: 8 }}>Test Score</div>
            <div style={{
              fontSize: '3rem', fontWeight: 700,
              color: passed ? 'var(--green)' : 'var(--red)',
            }}>
              {score}<span style={{ fontSize: '1.4rem' }}>/100</span>
            </div>
            <div style={{ fontWeight: 500, color: passed ? 'var(--green)' : 'var(--red)', marginTop: 4 }}>
              {passed ? 'Passed — Congratulations!' : `Below cut-off (${ELIGIBILITY.testPassMark} marks required)`}
            </div>
          </div>
        )}
      </div>
    );
  }

  // ── Not yet scheduled ──────────────────────────────────────
  return (
    <div className="card">
      <h2 style={{ margin: '0 0 0.5rem', fontWeight: 400 }}>Entrance Test Schedule</h2>
      <p style={{ color: 'var(--gray-600)', marginBottom: '2rem', fontSize: '0.9rem' }}>
        Book your entrance test slot. The test covers aptitude, physics, and general aviation knowledge.
      </p>

      {!myApplication && (
        <div className="alert alert-warning" style={{ marginBottom: '1.5rem' }}>
          <i className="ti ti-info-circle" />
          Please submit your application before scheduling a test.
        </div>
      )}

      <h3 style={{ fontWeight: 500, marginBottom: '1rem', fontSize: '1rem' }}>Available Slots</h3>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '1.5rem' }}>
        {TEST_SLOTS.map(slot => {
          const [date, ...timeParts] = slot.split(' ');
          const time = timeParts.join(' ');
          const isSelected = selected === slot;
          return (
            <div
              key={slot}
              onClick={() => myApplication && setSelected(slot)}
              style={{
                padding: '0.9rem 1rem',
                border: `1px solid ${isSelected ? 'var(--blue)' : 'var(--gray-200)'}`,
                borderRadius: 'var(--border-radius-md)',
                cursor: myApplication ? 'pointer' : 'not-allowed',
                background: isSelected ? 'var(--blue-light)' : '#fff',
                opacity: myApplication ? 1 : 0.5,
                transition: 'border-color 0.15s, background 0.15s',
              }}
            >
              <div style={{ fontSize: '0.78rem', color: 'var(--gray-600)' }}>
                <i className="ti ti-calendar" style={{ marginRight: 4 }} />{date}
              </div>
              <div style={{ fontWeight: 500, color: isSelected ? 'var(--blue)' : 'var(--navy)', marginTop: 2 }}>{time}</div>
              {isSelected && (
                <div style={{ fontSize: '0.75rem', color: 'var(--blue)', marginTop: 4 }}>
                  <i className="ti ti-check" style={{ marginRight: 4 }} />Selected
                </div>
              )}
            </div>
          );
        })}
      </div>

      <button
        className="btn btn-primary"
        onClick={handleConfirm}
        disabled={!myApplication || !selected}
      >
        <i className="ti ti-calendar-check" />Confirm Test Booking
      </button>
    </div>
  );
}
