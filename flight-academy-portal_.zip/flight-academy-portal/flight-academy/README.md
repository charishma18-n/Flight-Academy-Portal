# SkyWings Flight Academy — Admission Portal

A complete, production-structured React + Vite application for flight academy admissions.

---

## Quick Start 

# Step 1 — go into the project folder
cd flight-academy

# Step 2 — install dependencies
npm install

# Step 3 — start the dev server
npm start


Then open http://localhost:3000 in your browser.


## IMPORTANT — Do NOT run `npm audit fix --force`

That command can remove core dependencies like react-scripts or vite.
If you accidentally ran it, delete node_modules and package-lock.json, then reinstall:

```bash
# Fix broken install
rmdir /s /q node_modules       # Windows
npm install


## Project Structure


flight-academy/
├── index.html                       # Vite HTML entry point
├── vite.config.js                   # Vite configuration
├── package.json
├── README.md
│
└── src/
    ├── index.js                     # React entry point
    ├── App.jsx                      # Root router (page-based)
    │
    ├── styles/
    │   └── global.css               # Design tokens, utility classes, layout
    │
    ├── data/
    │   └── constants.js             # Seed data, courses, test slots, static config
    │
    ├── utils/
    │   └── helpers.js               # Pure functions: validation, formatting, IDs
    │
    ├── context/
    │   └── AppContext.js            # Global state + all business logic actions
    │
    ├── hooks/
    │   └── useForm.js               # Reusable form state hook
    │
    ├── components/
    │   ├── common/                  # Shared UI atoms
    │   │   ├── Toast.jsx
    │   │   ├── Navbar.jsx
    │   │   ├── Sidebar.jsx
    │   │   ├── FormField.jsx
    │   │   └── StatusBadge.jsx
    │   │
    │   ├── auth/
    │   │   └── AuthForm.jsx         # Login / Register / Forgot password
    │   │
    │   ├── dashboard/               # Applicant-facing tabs
    │   │   ├── OverviewTab.jsx
    │   │   ├── ApplicationForm.jsx  # 3-step eligibility + submission wizard
    │   │   ├── DocumentUpload.jsx
    │   │   ├── TestSchedule.jsx
    │   │   ├── StatusTracker.jsx
    │   │   └── ProfileTab.jsx
    │   │
    │   └── admin/                   # Admin-facing views
    │       ├── AdminSidebar.jsx
    │       ├── AdminStats.jsx
    │       ├── ApplicationsManager.jsx
    │       ├── TestScoresManager.jsx
    │       └── ApplicantsList.jsx
    │
    └── pages/
        ├── LandingPage.jsx
        ├── DashboardPage.jsx
        └── AdminPage.jsx
```
