/**
 * FormField — labelled input with leading icon.
 * Props: label, icon (ti-*), type, value, onChange, placeholder, dark
 */
export default function FormField({ label, icon, type = 'text', value, onChange, placeholder, dark = false }) {
  return (
    <div className="form-group">
      <label className="form-label" style={{ color: dark ? 'rgba(255,255,255,0.6)' : undefined }}>
        {label}
      </label>
      <div style={{ position: 'relative' }}>
        <i
          className={`ti ${icon}`}
          style={{
            position: 'absolute',
            left: 10,
            top: '50%',
            transform: 'translateY(-50%)',
            color: dark ? 'rgba(255,255,255,0.3)' : 'var(--gray-400)',
            fontSize: 16,
            pointerEvents: 'none',
          }}
        />
        <input
          type={type}
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          className={`form-input ${dark ? 'form-input-dark' : ''}`}
        />
      </div>
    </div>
  );
}
