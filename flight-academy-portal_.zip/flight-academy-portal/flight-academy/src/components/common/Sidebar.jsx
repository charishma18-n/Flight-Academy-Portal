import { DASHBOARD_TABS } from '../../data/constants';
import { useApp } from '../../context/AppContext';

export default function Sidebar({ activeTab, onTabChange }) {
  const { myApplication } = useApp();

  return (
    <div className="sidebar">
      {DASHBOARD_TABS.map(tab => (
        <button
          key={tab.id}
          className={`sidebar-item ${activeTab === tab.id ? 'active' : ''}`}
          onClick={() => onTabChange(tab.id)}
        >
          <i className={`ti ${tab.icon}`} style={{ fontSize: 16 }} />
          {tab.label}
        </button>
      ))}

      {/* Application ID card */}
      {myApplication && (
        <div style={{
          margin: '1rem',
          padding: '0.9rem',
          background: 'var(--blue-light)',
          borderRadius: 'var(--border-radius-md)',
        }}>
          <div style={{ fontSize: '0.72rem', color: 'var(--gray-600)', textTransform: 'uppercase', letterSpacing: '0.8px', marginBottom: 4 }}>
            Application ID
          </div>
          <div style={{ fontWeight: 700, color: 'var(--blue)', fontSize: '0.88rem' }}>
            {myApplication.id}
          </div>
          <div style={{ fontSize: '0.72rem', color: 'var(--gray-600)', marginTop: 4 }}>
            Submitted {myApplication.submittedDate}
          </div>
        </div>
      )}
    </div>
  );
}
