import { useState } from 'react';
import Navbar from '../components/common/Navbar';
import Sidebar from '../components/common/Sidebar';
import OverviewTab     from '../components/dashboard/OverviewTab';
import ApplicationForm from '../components/dashboard/ApplicationForm';
import DocumentUpload  from '../components/dashboard/DocumentUpload';
import TestSchedule    from '../components/dashboard/TestSchedule';
import StatusTracker   from '../components/dashboard/StatusTracker';
import ProfileTab      from '../components/dashboard/ProfileTab';

export default function DashboardPage() {
  const [activeTab, setActiveTab] = useState('overview');

  function renderTab() {
    switch (activeTab) {
      case 'overview':  return <OverviewTab     onTabChange={setActiveTab} />;
      case 'apply':     return <ApplicationForm onTabChange={setActiveTab} />;
      case 'documents': return <DocumentUpload />;
      case 'test':      return <TestSchedule />;
      case 'status':    return <StatusTracker  onTabChange={setActiveTab} />;
      case 'profile':   return <ProfileTab />;
      default:          return <OverviewTab     onTabChange={setActiveTab} />;
    }
  }

  return (
    <div style={{ minHeight: '100vh', background: 'var(--gray-50)' }}>
      <Navbar />
      <div style={{ display: 'flex', maxWidth: 1100, margin: '0 auto', padding: '1.5rem', gap: '1.5rem' }}>
        <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
        <div style={{ flex: 1, minWidth: 0 }}>
          {renderTab()}
        </div>
      </div>
    </div>
  );
}
