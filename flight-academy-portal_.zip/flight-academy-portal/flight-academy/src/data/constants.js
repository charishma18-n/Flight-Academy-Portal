// ─── Seed users ──────────────────────────────────────────────
export const SEED_USERS = [
  {
    id: 1,
    name: 'Demo User',
    email: 'demo@flyacademy.com',
    password: 'demo123',
    role: 'applicant',
    phone: '+91 98765 43210',
    address: 'Hyderabad, Telangana',
    applied: false,
  },
  {
    id: 2,
    name: 'Admin',
    email: 'admin@flyacademy.com',
    password: 'admin123',
    role: 'admin',
    applied: false,
  },
];

// ─── Seed applications ────────────────────────────────────────
export const SEED_APPLICATIONS = [
  {
    id: 'APP-2025-001',
    userId: 1,
    name: 'Demo User',
    email: 'demo@flyacademy.com',
    age: 22,
    education: 'BSc Aviation',
    medicalCert: 'Class 1',
    flightHours: 80,
    phone: '+91 98765 43210',
    address: 'Hyderabad, Telangana',
    course: 'Commercial Pilot License (CPL)',
    status: 'Under Review',
    submittedDate: '2025-05-10',
    documents: ['passport.pdf', 'medical_cert.pdf'],
    testScheduled: null,
    testScore: null,
    notifications: [
      'Application received successfully.',
      'Documents verified by our team.',
    ],
  },
];

// ─── Courses ──────────────────────────────────────────────────
export const COURSES = [
  {
    id: 1,
    name: 'Commercial Pilot License (CPL)',
    duration: '18 months',
    seats: 20,
    fee: '₹12,00,000',
    icon: 'ti-plane',
    description: 'Full professional pilot training for commercial aviation careers.',
  },
  {
    id: 2,
    name: 'Private Pilot License (PPL)',
    duration: '6 months',
    seats: 30,
    fee: '₹4,50,000',
    icon: 'ti-plane-departure',
    description: 'Introductory licence for personal and recreational flying.',
  },
  {
    id: 3,
    name: 'Instrument Rating (IR)',
    duration: '4 months',
    seats: 15,
    fee: '₹3,00,000',
    icon: 'ti-compass',
    description: 'Fly using instruments in low visibility and IFR conditions.',
  },
  {
    id: 4,
    name: 'Multi-Engine Rating (MER)',
    duration: '3 months',
    seats: 10,
    fee: '₹2,50,000',
    icon: 'ti-engine',
    description: 'Rating to operate aircraft with multiple engines.',
  },
];

// ─── Test slots ───────────────────────────────────────────────
export const TEST_SLOTS = [
  '2025-06-15 10:00 AM',
  '2025-06-15 02:00 PM',
  '2025-06-20 09:00 AM',
  '2025-06-20 03:00 PM',
  '2025-06-25 11:00 AM',
  '2025-06-28 10:00 AM',
];

// ─── Required documents list ──────────────────────────────────
export const REQUIRED_DOCS = [
  'Passport / Aadhaar Card',
  '10+2 Marksheet',
  'DGCA Medical Certificate',
  'Passport-size photographs (4 copies)',
  'Previous flight logbook',
  'Birth Certificate',
];

// ─── Application statuses & their style map ───────────────────
export const STATUS_STYLES = {
  'Submitted':          { bg: '#E6F1FB', color: '#185FA5' },
  'Under Review':       { bg: '#FAEEDA', color: '#BA7517' },
  'Documents Verified': { bg: '#EAF3DE', color: '#3B6D11' },
  'Test Scheduled':     { bg: '#EEEDFE', color: '#534AB7' },
  'Accepted':           { bg: '#E1F5EE', color: '#0F6E56' },
  'Waitlisted':         { bg: '#FAECE7', color: '#993C1D' },
  'Rejected':           { bg: '#FCEBEB', color: '#A32D2D' },
};

// ─── Nav tabs for applicant dashboard ────────────────────────
export const DASHBOARD_TABS = [
  { id: 'overview',  icon: 'ti-layout-dashboard', label: 'Overview' },
  { id: 'apply',     icon: 'ti-file-plus',         label: 'Apply' },
  { id: 'documents', icon: 'ti-upload',            label: 'Documents' },
  { id: 'test',      icon: 'ti-calendar-event',    label: 'Test Schedule' },
  { id: 'status',    icon: 'ti-timeline',          label: 'Status & Updates' },
  { id: 'profile',   icon: 'ti-user',              label: 'Profile' },
];

// ─── Admin nav items ──────────────────────────────────────────
export const ADMIN_TABS = [
  { id: 'stats',        icon: 'ti-layout-dashboard', label: 'Dashboard' },
  { id: 'applications', icon: 'ti-file-text',         label: 'Applications' },
  { id: 'scores',       icon: 'ti-chart-bar',         label: 'Test Scores' },
  { id: 'users',        icon: 'ti-users',             label: 'Applicants' },
];

// ─── Eligibility rules ────────────────────────────────────────
export const ELIGIBILITY = {
  minAge: 17,
  maxAge: 35,
  minFlightHours: 40,
  testPassMark: 60,
};

// ─── Academy info ─────────────────────────────────────────────
export const ACADEMY = {
  name: 'SkyWings Flight Academy',
  tagline: 'Flight Training Excellence',
  estYear: 1998,
  dgcaLicense: 'FTA-2025-HYD',
  email: 'admission@skywings.edu.in',
  phone: '+91 40 6600 1234',
  address: 'Begumpet, Hyderabad, Telangana – 500016',
  venue: 'SkyWings Academy, Begumpet, Hyderabad | Hall B, 2nd Floor',
  stats: [
    { icon: 'ti-certificate', value: '25+',   label: 'Years of Excellence' },
    { icon: 'ti-users',       value: '3,200+', label: 'Pilots Trained' },
    { icon: 'ti-plane',       value: '48',     label: 'Training Aircraft' },
    { icon: 'ti-award',       value: 'DGCA',   label: 'Certified Academy' },
  ],
  heroImage: 'https://images.unsplash.com/photo-1436891620584-47fd0e565afb?w=1400&q=80',
  cockpitImage: 'https://images.unsplash.com/photo-1464037866556-6812c9d1c72e?w=1400&q=80',
};
