import { useState } from 'react';

/**
 * Lightweight form state hook.
 * @param {object} initialValues - Initial field values
 * @returns {{ values, error, set, setError, reset }}
 */
export default function useForm(initialValues) {
  const [values, setValues] = useState(initialValues);
  const [error, setError]   = useState('');

  function set(field, value) {
    setValues(prev => ({ ...prev, [field]: value }));
    setError('');
  }

  function reset() {
    setValues(initialValues);
    setError('');
  }

  return { values, error, set, setError, reset };
}
