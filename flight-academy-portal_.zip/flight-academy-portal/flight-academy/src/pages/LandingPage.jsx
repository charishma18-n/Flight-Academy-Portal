import { useApp } from '../context/AppContext';
import { ACADEMY, COURSES } from '../data/constants';

export default function LandingPage() {
  const { setPage } = useApp();

  return (
    <div style={{ fontFamily: 'var(--font-serif)', minHeight: '100vh', background: 'var(--navy)' }}>

      {/* ── Hero ─────────────────────────────────────────────── */}
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        flexDirection: 'column',
        background: `linear-gradient(to bottom,rgba(10,15,30,0.85) 0%,rgba(10,15,30,0.6) 40%,rgba(10,15,30,0.95) 100%),url(${ACADEMY.heroImage}) center/cover no-repeat`,
      }}>
        {/* Nav */}
        <nav style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          padding: '1.5rem 3rem',
          borderBottom: '1px solid rgba(255,255,255,0.08)',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{ width: 40, height: 40, background: 'var(--blue)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <i className="ti ti-plane-tilt" style={{ color: '#fff', fontSize: 20 }} />
            </div>
            <div>
              <div style={{ color: '#fff', fontWeight: 700, fontSize: 18 }}>{ACADEMY.name}</div>
              <div style={{ color: 'var(--blue-mid)', fontSize: 11, letterSpacing: '2px', textTransform: 'uppercase' }}>{ACADEMY.tagline}</div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            <button
              onClick={() => setPage('auth')}
              style={{ padding: '0.5rem 1.5rem', background: 'transparent', color: '#fff', border: '1px solid rgba(255,255,255,0.3)', borderRadius: 6, fontFamily: 'var(--font-sans)' }}
            >
              Sign In
            </button>
            <button
              onClick={() => setPage('auth')}
              style={{ padding: '0.5rem 1.5rem', background: 'var(--blue)', color: '#fff', border: 'none', borderRadius: 6, fontFamily: 'var(--font-sans)' }}
            >
              Apply Now
            </button>
          </div>
        </nav>

        {/* Hero copy */}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', padding: '4rem 2rem', textAlign: 'center' }}>
          <div style={{ fontSize: 11, letterSpacing: '4px', textTransform: 'uppercase', color: 'var(--blue-mid)', marginBottom: '1rem' }}>
            DGCA Approved | Est. {ACADEMY.estYear}
          </div>
          <h1 style={{ fontSize: 'clamp(2.5rem, 6vw, 4.5rem)', color: '#fff', margin: '0 0 1.5rem', fontWeight: 400, lineHeight: 1.15, maxWidth: 700 }}>
            Begin Your Journey<br />to the <em style={{ color: 'var(--blue-mid)' }}>Skies</em>
          </h1>
          <p style={{ color: 'rgba(255,255,255,0.65)', fontSize: '1.1rem', maxWidth: 520, lineHeight: 1.8, marginBottom: '2.5rem' }}>
            India's premier flight training academy. Apply online, track your admission, schedule your entrance test — all in one place.
          </p>
          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', justifyContent: 'center' }}>
            <button
              onClick={() => setPage('auth')}
              style={{ padding: '0.9rem 2.5rem', background: 'var(--blue)', color: '#fff', border: 'none', borderRadius: 6, fontSize: '1rem', fontFamily: 'var(--font-sans)' }}
            >
              Start Application
            </button>
            <button
              onClick={() => setPage('auth')}
              style={{ padding: '0.9rem 2.5rem', background: 'transparent', color: '#fff', border: '1px solid rgba(255,255,255,0.3)', borderRadius: 6, fontSize: '1rem', fontFamily: 'var(--font-sans)' }}
            >
              View Courses
            </button>
          </div>
        </div>

        {/* Stats strip */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1px', background: 'rgba(255,255,255,0.08)', borderTop: '1px solid rgba(255,255,255,0.08)' }}>
          {ACADEMY.stats.map((s, i) => (
            <div key={i} style={{ padding: '2rem', textAlign: 'center', background: 'rgba(10,15,30,0.7)' }}>
              <i className={`ti ${s.icon}`} style={{ fontSize: 28, color: 'var(--blue-mid)', display: 'block', marginBottom: '0.5rem' }} />
              <div style={{ fontSize: '1.8rem', color: '#fff', fontWeight: 700 }}>{s.value}</div>
              <div style={{ fontSize: '0.78rem', color: 'rgba(255,255,255,0.5)', letterSpacing: '1px', textTransform: 'uppercase', marginTop: 4 }}>{s.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* ── Courses ───────────────────────────────────────────── */}
      <div style={{ background: 'var(--navy-light)', padding: '4rem 3rem' }}>
        <h2 style={{ color: '#fff', textAlign: 'center', fontWeight: 400, fontSize: '1.8rem', marginBottom: '0.5rem' }}>
          Courses Offered
        </h2>
        <p style={{ color: 'rgba(255,255,255,0.4)', textAlign: 'center', marginBottom: '3rem' }}>
          Choose the programme that matches your aviation goals
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))', gap: '1.5rem', maxWidth: 960, margin: '0 auto' }}>
          {COURSES.map(c => (
            <div key={c.id} style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 10, padding: '1.5rem' }}>
              <i className={`ti ${c.icon}`} style={{ fontSize: 32, color: 'var(--blue-mid)', marginBottom: '1rem', display: 'block' }} />
              <div style={{ color: '#fff', fontWeight: 600, marginBottom: '0.5rem' }}>{c.name}</div>
              <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.85rem', marginBottom: '0.4rem' }}>
                <i className="ti ti-clock" style={{ marginRight: 4 }} />{c.duration}
              </div>
              <div style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.85rem', marginBottom: '1rem' }}>
                <i className="ti ti-users" style={{ marginRight: 4 }} />{c.seats} seats
              </div>
              <div style={{ color: 'var(--blue-mid)', fontWeight: 700, fontSize: '1.1rem' }}>{c.fee}</div>
              <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.82rem', marginTop: 8, lineHeight: 1.5 }}>{c.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── CTA ───────────────────────────────────────────────── */}
      <div style={{ background: 'var(--blue)', padding: '3rem', textAlign: 'center' }}>
        <h2 style={{ color: '#fff', fontWeight: 400, fontSize: '1.6rem', marginBottom: '0.75rem' }}>Ready to take flight?</h2>
        <p style={{ color: 'rgba(255,255,255,0.7)', marginBottom: '1.5rem' }}>Applications are open. Limited seats available for 2025 batch.</p>
        <button
          onClick={() => setPage('auth')}
          style={{ padding: '0.9rem 2.5rem', background: '#fff', color: 'var(--blue)', border: 'none', borderRadius: 6, fontWeight: 600, fontSize: '1rem', fontFamily: 'var(--font-sans)' }}
        >
          Apply Now
        </button>
      </div>

      {/* ── Footer ────────────────────────────────────────────── */}
      <div style={{ background: 'var(--navy)', padding: '2rem 3rem', borderTop: '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.5rem' }}>
          <div>
            <div style={{ color: '#fff', fontWeight: 600, marginBottom: 4 }}>{ACADEMY.name}</div>
            <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.85rem' }}>{ACADEMY.address}</div>
          </div>
          <div>
            <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.85rem', marginBottom: 4 }}>
              <i className="ti ti-mail" style={{ marginRight: 6 }} />{ACADEMY.email}
            </div>
            <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.85rem' }}>
              <i className="ti ti-phone" style={{ marginRight: 6 }} />{ACADEMY.phone}
            </div>
          </div>
        </div>
        <div style={{ borderTop: '1px solid rgba(255,255,255,0.06)', paddingTop: '1.5rem', color: 'rgba(255,255,255,0.25)', fontSize: '0.8rem', textAlign: 'center' }}>
          © 2025 {ACADEMY.name} | DGCA License No. {ACADEMY.dgcaLicense}
        </div>
      </div>
    </div>
  );
}
