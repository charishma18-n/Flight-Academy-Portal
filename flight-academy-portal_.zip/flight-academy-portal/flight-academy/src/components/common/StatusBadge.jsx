import { getStatusStyle } from '../../utils/helpers';

export default function StatusBadge({ status, size = 'normal' }) {
  const style = getStatusStyle(status);
  return (
    <span
      className="badge"
      style={{
        background: style.bg,
        color: style.color,
        fontSize: size === 'large' ? '0.88rem' : '0.78rem',
        padding: size === 'large' ? '0.35rem 1.1rem' : '0.2rem 0.75rem',
      }}
    >
      {status}
    </span>
  );
}
