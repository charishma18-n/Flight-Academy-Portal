import { useApp } from '../../context/AppContext';
import StatusBadge from '../common/StatusBadge';

const STATUSES = ['Under Review', 'Documents Verified', 'Test Scheduled', 'Accepted', 'Waitlisted', 'Rejected'];

export default function ApplicationsManager() {
  const { applications, adminSetStatus } = useApp();

  return (
    <div>
      <h2 style={{ marginBottom: '1.5rem', fontWeight: 400 }}>All Applications</h2>

      {applications.length === 0 && (
        <div className="card" style={{ textAlign: 'center', color: 'var(--gray-600)', padding: '3rem' }}>
          No applications submitted yet.
        </div>
      )}

      {applications.map(a => (
        <div key={a.id} className="card" style={{ marginBottom: '1rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem' }}>

            {/* Applicant info */}
            <div style={{ minWidth: 220 }}>
              <div style={{ fontWeight: 600, fontSize: '1rem', marginBottom: 4 }}>
                {a.name}
                <span style={{ fontWeight: 400, color: 'var(--gray-600)', fontSize: '0.82rem', marginLeft: 8 }}>({a.id})</span>
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--gray-800)', marginBottom: 3 }}>
                <i className="ti ti-mail" style={{ marginRight: 4 }} />{a.email}
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--gray-800)', marginBottom: 3 }}>
                <i className="ti ti-calendar" style={{ marginRight: 4 }} />Applied: {a.submittedDate}
                &nbsp;|&nbsp;
                <i className="ti ti-plane" style={{ marginRight: 4 }} />{a.course || 'CPL'}
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--gray-800)' }}>
                <i className="ti ti-files" style={{ marginRight: 4 }} />
                Docs: {a.documents.length > 0 ? a.documents.join(', ') : 'None uploaded'}
              </div>
              {a.testScheduled && (
                <div style={{ fontSize: '0.85rem', color: 'var(--gray-800)', marginTop: 3 }}>
                  <i className="ti ti-calendar-event" style={{ marginRight: 4 }} />Test: {a.testScheduled}
                </div>
              )}
            </div>

            {/* Status + actions */}
            <div style={{ textAlign: 'right' }}>
              <StatusBadge status={a.status} size="large" />
              <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap', justifyContent: 'flex-end', marginTop: 10 }}>
                {STATUSES.map(s => (
                  <button
                    key={s}
                    onClick={() => adminSetStatus(a.id, s)}
                    style={{
                      padding: '0.22rem 0.55rem',
                      fontSize: '0.72rem',
                      border: '1px solid var(--gray-200)',
                      borderRadius: 4,
                      cursor: 'pointer',
                      background: a.status === s ? 'var(--blue-light)' : '#fff',
                      color: a.status === s ? 'var(--blue)' : 'var(--gray-800)',
                      fontWeight: a.status === s ? 600 : 400,
                    }}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
