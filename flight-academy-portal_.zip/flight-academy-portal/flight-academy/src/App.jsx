import { AppProvider, useApp } from './context/AppContext';
import Toast        from './components/common/Toast';
import LandingPage  from './pages/LandingPage';
import AuthForm     from './components/auth/AuthForm';
import DashboardPage from './pages/DashboardPage';
import AdminPage    from './pages/AdminPage';

function Router() {
  const { page } = useApp();

  switch (page) {
    case 'landing':   return <LandingPage />;
    case 'auth':      return <AuthForm />;
    case 'dashboard': return <DashboardPage />;
    case 'admin':     return <AdminPage />;
    default:          return <LandingPage />;
  }
}

export default function App() {
  return (
    <AppProvider>
      <Toast />
      <Router />
    </AppProvider>
  );
}
