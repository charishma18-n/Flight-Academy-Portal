import { useApp } from '../../context/AppContext';

export default function Toast() {
  const { toast } = useApp();
  if (!toast) return null;

  const isError = toast.type === 'error';
  return (
    <div
      className="toast"
      style={{
        background: isError ? 'var(--red-light)'   : 'var(--green-light)',
        color:      isError ? 'var(--red)'         : 'var(--green)',
        border:     isError ? '1px solid #F7C1C1' : '1px solid var(--green-mid)',
      }}
    >
      <i className={`ti ${isError ? 'ti-alert-circle' : 'ti-circle-check'}`} />
      {toast.msg}
    </div>
  );
}
