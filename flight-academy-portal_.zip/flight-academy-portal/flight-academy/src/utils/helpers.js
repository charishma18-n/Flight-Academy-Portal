import { STATUS_STYLES } from '../data/constants';

/** Generate a random application ID */
export function generateAppId() {
  const num = String(Math.floor(Math.random() * 900) + 100);
  return `APP-${new Date().getFullYear()}-${num}`;
}

/** Today's date as YYYY-MM-DD */
export function todayString() {
  return new Date().toISOString().slice(0, 10);
}

/** Get badge style object for a given application status */
export function getStatusStyle(status) {
  return STATUS_STYLES[status] || { bg: '#f0f0f0', color: '#555' };
}

/** Validate email format */
export function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

/** Return initials from a full name (max 2 chars) */
export function getInitials(name = '') {
  return name
    .split(' ')
    .slice(0, 2)
    .map(w => w[0]?.toUpperCase() || '')
    .join('');
}

/** Check if a string is all the same repeated character e.g. "111111" or "aaaaaaa" */
function isRepeating(str) {
  return str.length > 2 && /^(.)\1+$/.test(str.replace(/\s/g, ''));
}

/** Check if a string is a sequential pattern e.g. "123456", "abcdef" */
function isSequential(str) {
  const s = str.replace(/\s/g, '');
  if (s.length < 4) return false;
  let seq = true;
  for (let i = 1; i < s.length; i++) {
    if (s.charCodeAt(i) - s.charCodeAt(i - 1) !== 1) { seq = false; break; }
  }
  return seq;
}

/** Check that a name/text field looks real (letters, spaces, dots, hyphens only) */
function isValidName(str) {
  return /^[A-Za-z\s.\-']+$/.test(str.trim()) && str.trim().length >= 2;
}

/** Validate Indian phone number */
function isValidPhone(phone) {
  const digits = phone.replace(/[\s\-+()]/g, '');
  // Must be 10 digits (optionally prefixed with 91 or +91)
  const stripped = digits.startsWith('91') && digits.length === 12
    ? digits.slice(2)
    : digits;
  if (stripped.length !== 10) return false;
  if (!/^[6-9]\d{9}$/.test(stripped)) return false;
  if (isRepeating(stripped)) return false;
  return true;
}

/** Validate education field — must contain real words, not just numbers */
function isValidEducation(edu) {
  const trimmed = edu.trim();
  if (trimmed.length < 3) return false;
  if (/^\d+$/.test(trimmed)) return false;          // all digits
  if (isRepeating(trimmed)) return false;            // "222222222"
  if (isSequential(trimmed)) return false;           // "123456"
  if (!/[A-Za-z]/.test(trimmed)) return false;      // must have at least one letter
  return true;
}

/** Validate address — must have letters and be meaningful */
function isValidAddress(addr) {
  const trimmed = addr.trim();
  if (trimmed.length < 5) return false;
  if (/^\d+$/.test(trimmed)) return false;
  if (isRepeating(trimmed)) return false;
  if (isSequential(trimmed)) return false;
  if (!/[A-Za-z]/.test(trimmed)) return false;
  return true;
}

/** Validate eligibility form and return first error or null */
export function validateEligibility({ age, education, medicalCert, flightHours }) {
  if (!age || !education || !medicalCert || !flightHours)
    return 'All fields are required.';

  const a = parseInt(age);
  if (isNaN(a) || a < 17 || a > 35)
    return 'Age must be between 17 and 35.';

  const fh = parseInt(flightHours);
  if (isNaN(fh) || fh < 0 || fh > 50000)
    return 'Please enter a valid number of flight hours.';
  if (fh < 40)
    return 'Minimum 40 flight hours required for eligibility.';

  // Education is now a dropdown — just check it's selected
  if (education.trim().length < 2)
    return 'Please select your educational qualification.';

  return null;
}

/** Validate personal info form */
export function validatePersonalInfo({ phone, address, course }) {
  if (!phone || !address || !course)
    return 'All fields are required.';

  if (!isValidPhone(phone))
    return 'Please enter a valid 10-digit Indian mobile number (starting with 6–9).';

  if (!isValidAddress(address))
    return 'Please enter a valid address (e.g. "42, MG Road, Hyderabad, Telangana").';

  return null;
}

/** Validate auth forms */
export function validateLogin({ email, password }) {
  if (!email || !password) return 'Email and password are required.';
  if (!isValidEmail(email)) return 'Please enter a valid email address.';
  return null;
}

export function validateRegister({ name, email, password, confirm }) {
  if (!name || !email || !password) return 'All fields are required.';

  if (!isValidName(name))
    return 'Name should contain only letters and spaces (e.g. "Amrutha Reddy").';
  if (isRepeating(name.replace(/\s/g, '')))
    return 'Please enter your real full name.';

  if (!isValidEmail(email))
    return 'Please enter a valid email address.';

  if (password.length < 6)
    return 'Password must be at least 6 characters.';
  if (isRepeating(password))
    return 'Please choose a stronger password.';
  if (password !== confirm)
    return 'Passwords do not match.';

  return null;
}
