import { useApp } from '../../context/AppContext';
import { getInitials } from '../../utils/helpers';

export default function ApplicantsList() {
  const { users, applications } = useApp();
  const applicants = users.filter(u => u.role === 'applicant');

  return (
    <div>
      <h2 style={{ marginBottom: '1.5rem', fontWeight: 400 }}>All Applicants</h2>

      {applicants.map(u => {
        const app = applications.find(a => a.userId === u.id);
        return (
          <div key={u.id} className="card" style={{ marginBottom: '1rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>

            <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
              <div style={{
                width: 44, height: 44, background: 'var(--blue-light)',
                borderRadius: '50%', display: 'flex', alignItems: 'center',
                justifyContent: 'center', fontWeight: 700, color: 'var(--blue)', fontSize: 15,
              }}>
                {getInitials(u.name)}
              </div>
              <div>
                <div style={{ fontWeight: 600 }}>{u.name}</div>
                <div style={{ fontSize: '0.85rem', color: 'var(--gray-600)' }}>
                  <i className="ti ti-mail" style={{ marginRight: 4 }} />{u.email}
                </div>
                {app && (
                  <div style={{ fontSize: '0.78rem', color: 'var(--gray-600)', marginTop: 2 }}>
                    <i className="ti ti-file-text" style={{ marginRight: 4 }} />{app.id} — {app.course || 'CPL'}
                  </div>
                )}
              </div>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 6 }}>
              <span
                className="badge"
                style={{
                  background: u.applied ? 'var(--green-light)' : 'var(--gray-100)',
                  color:      u.applied ? 'var(--green)'       : 'var(--gray-600)',
                }}
              >
                {u.applied ? 'Applied' : 'Not Applied'}
              </span>
              {app && (
                <span
                  className="badge"
                  style={{ background: 'var(--blue-light)', color: 'var(--blue)' }}
                >
                  {app.status}
                </span>
              )}
            </div>
          </div>
        );
      })}

      {applicants.length === 0 && (
        <div className="card" style={{ textAlign: 'center', color: 'var(--gray-600)', padding: '3rem' }}>
          No applicants registered yet.
        </div>
      )}
    </div>
  );
}
