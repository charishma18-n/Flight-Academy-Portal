import { useApp } from '../../context/AppContext';
import { getInitials } from '../../utils/helpers';
import useForm from '../../hooks/useForm';

export default function ProfileTab() {
  const { user, myApplication, logout, showToast } = useApp();
  const { values, set } = useForm({ current: '', newPw: '' });

  function handlePasswordChange() {
    if (!values.current || !values.newPw) { showToast('Please fill both fields', 'error'); return; }
    if (values.newPw.length < 6) { showToast('New password must be at least 6 characters', 'error'); return; }
    showToast('Password updated successfully');
  }

  const rows = [
    ['Full Name',          user.name,                           'ti-user'],
    ['Email Address',      user.email,                          'ti-mail'],
    ['Application ID',     myApplication ? myApplication.id : 'Not applied', 'ti-file-text'],
    ['Status',             myApplication ? myApplication.status : 'N/A',     'ti-timeline'],
    ['Course Applied',     myApplication?.course || 'N/A',      'ti-plane'],
    ['Test Date',          myApplication?.testScheduled || 'Not scheduled', 'ti-calendar'],
  ];

  return (
    <div className="card">
      <h2 style={{ margin: '0 0 1.5rem', fontWeight: 400 }}>My Profile</h2>

      {/* Avatar block */}
      <div style={{
        display: 'flex', gap: 16, alignItems: 'center',
        padding: '1.25rem', background: '#f8faff',
        borderRadius: 'var(--border-radius-lg)', marginBottom: '2rem',
      }}>
        <div style={{
          width: 64, height: 64, borderRadius: '50%',
          background: 'var(--blue)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontWeight: 700, color: '#fff', fontSize: 22,
        }}>
          {getInitials(user.name)}
        </div>
        <div>
          <div style={{ fontWeight: 600, fontSize: '1.1rem' }}>{user.name}</div>
          <div style={{ color: 'var(--gray-600)', fontSize: '0.88rem' }}>{user.email}</div>
          <span className="badge" style={{ background: 'var(--blue-light)', color: 'var(--blue)', marginTop: 6, display: 'inline-flex' }}>
            Applicant
          </span>
        </div>
      </div>

      {/* Info rows */}
      {rows.map(([label, value, icon]) => (
        <div key={label} style={{
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          padding: '0.75rem 0', borderBottom: '1px solid var(--gray-100)', fontSize: '0.9rem',
        }}>
          <div style={{ color: 'var(--gray-600)', display: 'flex', alignItems: 'center', gap: 8 }}>
            <i className={`ti ${icon}`} style={{ fontSize: 16 }} />{label}
          </div>
          <div style={{ fontWeight: 500 }}>{value}</div>
        </div>
      ))}

      {/* Change password */}
      <div style={{ marginTop: '2rem', padding: '1.25rem', background: '#f8faff', borderRadius: 'var(--border-radius-md)' }}>
        <div style={{ fontWeight: 600, marginBottom: '1rem' }}>Change Password</div>
        <div className="form-group">
          <label className="form-label">Current Password</label>
          <input type="password" className="form-input" style={{ paddingLeft: '0.75rem' }}
            value={values.current} onChange={e => set('current', e.target.value)} placeholder="Current password" />
        </div>
        <div className="form-group">
          <label className="form-label">New Password</label>
          <input type="password" className="form-input" style={{ paddingLeft: '0.75rem' }}
            value={values.newPw} onChange={e => set('newPw', e.target.value)} placeholder="New password (min 6 chars)" />
        </div>
        <button className="btn btn-primary" onClick={handlePasswordChange}>Update Password</button>
      </div>

      {/* Sign out */}
      <button
        onClick={logout}
        style={{
          marginTop: '1.5rem', padding: '0.6rem 1.5rem',
          background: 'var(--red-light)', color: 'var(--red)',
          border: '1px solid #F7C1C1', borderRadius: 'var(--border-radius-sm)',
          display: 'flex', alignItems: 'center', gap: 6,
        }}
      >
        <i className="ti ti-logout" />Sign Out
      </button>
    </div>
  );
}
