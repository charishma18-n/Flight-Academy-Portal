import { useApp } from '../../context/AppContext';
import { getInitials, getStatusStyle } from '../../utils/helpers';
import { ACADEMY } from '../../data/constants';

export default function Navbar() {
  const { user, logout, myApplication } = useApp();

  return (
    <nav style={{
      background: 'var(--navy)',
      padding: '0.75rem 2rem',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      position: 'sticky',
      top: 0,
      zIndex: 100,
    }}>
      {/* Brand */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <div style={{
          width: 34, height: 34,
          background: 'var(--blue)',
          borderRadius: '50%',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
        }}>
          <i className="ti ti-plane-tilt" style={{ color: '#fff', fontSize: 16 }} />
        </div>
        <span style={{ color: '#fff', fontWeight: 600, fontFamily: 'var(--font-serif)' }}>
          {ACADEMY.name}
        </span>
      </div>

      {/* Right side */}
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        {myApplication && (
          <span
            className="badge"
            style={{
              background: getStatusStyle(myApplication.status).bg,
              color: getStatusStyle(myApplication.status).color,
              fontSize: '0.78rem',
            }}
          >
            {myApplication.status}
          </span>
        )}

        {/* Avatar */}
        <div style={{
          width: 32, height: 32,
          borderRadius: '50%',
          background: 'var(--blue)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontWeight: 600, color: '#fff', fontSize: 13,
        }}>
          {getInitials(user?.name)}
        </div>

        <span style={{ color: 'rgba(255,255,255,0.7)', fontSize: '0.85rem' }}>
          {user?.name}
        </span>

        <button
          onClick={logout}
          style={{
            background: 'rgba(255,255,255,0.08)',
            border: '1px solid rgba(255,255,255,0.12)',
            color: '#fff',
            padding: '0.3rem 0.8rem',
            borderRadius: 'var(--border-radius-sm)',
            fontSize: '0.8rem',
          }}
        >
          <i className="ti ti-logout" style={{ marginRight: 4 }} />
          Logout
        </button>
      </div>
    </nav>
  );
}
