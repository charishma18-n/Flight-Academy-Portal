import React, { createContext, useContext, useState, useCallback } from 'react';
import { SEED_USERS, SEED_APPLICATIONS } from '../data/constants';
import { generateAppId, todayString } from '../utils/helpers';

const AppContext = createContext(null);

export function AppProvider({ children }) {
  const [page, setPage]               = useState('landing');   // landing | auth | dashboard | admin
  const [user, setUser]               = useState(null);
  const [users, setUsers]             = useState(SEED_USERS);
  const [applications, setApplications] = useState(SEED_APPLICATIONS);
  const [toast, setToast]             = useState(null);         // { msg, type }

  /* ── Toast helper ─────────────────────────────────── */
  const showToast = useCallback((msg, type = 'success') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3000);
  }, []);

  /* ── Auth actions ─────────────────────────────────── */
  function login(email, password) {
    const found = users.find(u => u.email === email && u.password === password);
    if (!found) return 'Invalid email or password.';
    setUser(found);
    setPage(found.role === 'admin' ? 'admin' : 'dashboard');
    showToast(`Welcome back, ${found.name}!`);
    return null;
  }

  function register({ name, email, password }) {
    if (users.find(u => u.email === email)) return 'Email is already registered.';
    const newUser = {
      id: Date.now(), name, email, password,
      role: 'applicant', applied: false,
    };
    setUsers(prev => [...prev, newUser]);
    setUser(newUser);
    setPage('dashboard');
    showToast('Account created successfully!');
    return null;
  }

  function logout() {
    setUser(null);
    setPage('landing');
    showToast('You have been signed out.');
  }

  function resetPassword(email) {
    const found = users.find(u => u.email === email);
    if (!found) return 'No account found with that email.';
    showToast(`Password reset link sent to ${email}`);
    return null;
  }

  /* ── Application actions ──────────────────────────── */
  function submitApplication(formData) {
    const newApp = {
      id: generateAppId(),
      userId: user.id,
      name: user.name,
      email: user.email,
      ...formData,
      status: 'Submitted',
      submittedDate: todayString(),
      documents: [],
      testScheduled: null,
      testScore: null,
      notifications: ['Application submitted successfully. We will review within 5 business days.'],
    };
    setApplications(prev => [...prev, newApp]);
    setUsers(prev => prev.map(u => u.id === user.id ? { ...u, applied: true } : u));
    setUser(prev => ({ ...prev, applied: true }));
    showToast('Application submitted successfully!');
  }

  function uploadDocuments(appId, fileNames) {
    setApplications(prev => prev.map(a =>
      a.id === appId
        ? { ...a, documents: [...new Set([...a.documents, ...fileNames])] }
        : a
    ));
    showToast(`${fileNames.length} file(s) uploaded`);
  }

  function scheduleTest(appId, slot) {
    setApplications(prev => prev.map(a =>
      a.id === appId
        ? {
            ...a,
            testScheduled: slot,
            status: 'Test Scheduled',
            notifications: [...a.notifications, `Entrance test scheduled: ${slot}`],
          }
        : a
    ));
    showToast(`Test scheduled for ${slot}`);
  }

  /* ── Admin actions ────────────────────────────────── */
  function adminSetStatus(appId, status) {
    setApplications(prev => prev.map(a =>
      a.id === appId
        ? { ...a, status, notifications: [...a.notifications, `Status updated to: ${status}`] }
        : a
    ));
    showToast(`Status updated to ${status}`);
  }

  function adminSetScore(appId, score) {
    const s = parseInt(score);
    const status = s >= 60 ? 'Accepted' : 'Waitlisted';
    setApplications(prev => prev.map(a =>
      a.id === appId
        ? {
            ...a,
            testScore: score,
            status,
            notifications: [...a.notifications, `Test score recorded: ${score}/100`],
          }
        : a
    ));
    showToast('Score recorded');
  }

  /* ── Derived helpers ──────────────────────────────── */
  const myApplication = applications.find(a => a.userId === user?.id) || null;

  return (
    <AppContext.Provider value={{
      page, setPage,
      user, users,
      applications,
      toast,
      myApplication,
      showToast,
      login, register, logout, resetPassword,
      submitApplication, uploadDocuments, scheduleTest,
      adminSetStatus, adminSetScore,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside <AppProvider>');
  return ctx;
}
