import { useState } from 'react';
import AdminSidebar        from '../components/admin/AdminSidebar';
import AdminStats          from '../components/admin/AdminStats';
import ApplicationsManager from '../components/admin/ApplicationsManager';
import TestScoresManager   from '../components/admin/TestScoresManager';
import ApplicantsList      from '../components/admin/ApplicantsList';

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState('stats');

  function renderTab() {
    switch (activeTab) {
      case 'stats':        return <AdminStats />;
      case 'applications': return <ApplicationsManager />;
      case 'scores':       return <TestScoresManager />;
      case 'users':        return <ApplicantsList />;
      default:             return <AdminStats />;
    }
  }

  return (
    <div style={{ minHeight: '100vh', background: 'var(--gray-50)', display: 'flex', flexDirection: 'column' }}>
      {/* Top bar */}
      <div style={{ background: 'var(--navy)', padding: '0.85rem 2rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 32, height: 32, background: 'var(--blue)', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <i className="ti ti-plane-tilt" style={{ color: '#fff', fontSize: 16 }} />
          </div>
          <div>
            <div style={{ color: '#fff', fontWeight: 600, fontSize: '0.95rem' }}>SkyWings Admin</div>
            <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.72rem', letterSpacing: '1px', textTransform: 'uppercase' }}>Control Panel</div>
          </div>
        </div>
        <span style={{ color: 'rgba(255,255,255,0.5)', fontSize: '0.82rem' }}>
          <i className="ti ti-shield-check" style={{ marginRight: 6, color: 'var(--blue-mid)' }} />Administrator
        </span>
      </div>

      {/* Body */}
      <div style={{ display: 'flex', flex: 1 }}>
        <AdminSidebar activeTab={activeTab} onTabChange={setActiveTab} />
        <div className="main-content">
          {renderTab()}
        </div>
      </div>
    </div>
  );
}
