import { useState } from 'react';
import { useApp } from '../../context/AppContext';
import FormField from '../common/FormField';
import useForm from '../../hooks/useForm';
import { validateLogin, validateRegister } from '../../utils/helpers';
import { ACADEMY } from '../../data/constants';

export default function AuthForm() {
  const { login, register, resetPassword, setPage } = useApp();
  const [mode, setMode] = useState('login'); // login | register | forgot

  const { values, error, set, setError, reset } = useForm({
    name: '', email: '', password: '', confirm: '',
  });

  function switchMode(m) {
    setMode(m);
    reset();
  }

  function handleSubmit(e) {
    e.preventDefault();

    if (mode === 'login') {
      const err = validateLogin(values);
      if (err) { setError(err); return; }
      const apiErr = login(values.email, values.password);
      if (apiErr) setError(apiErr);

    } else if (mode === 'register') {
      const err = validateRegister(values);
      if (err) { setError(err); return; }
      const apiErr = register(values);
      if (apiErr) setError(apiErr);

    } else {
      if (!values.email) { setError('Please enter your email.'); return; }
      const apiErr = resetPassword(values.email);
      if (apiErr) setError(apiErr);
      else switchMode('login');
    }
  }

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      fontFamily: 'var(--font-serif)',
      background: `linear-gradient(135deg,rgba(10,15,30,0.92),rgba(10,15,30,0.85)),url(${ACADEMY.cockpitImage}) center/cover no-repeat`,
    }}>
      <div style={{ margin: 'auto', width: '100%', maxWidth: 440, padding: '2rem' }}>

        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
          <div style={{
            width: 52, height: 52, background: 'var(--blue)', borderRadius: '50%',
            display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1rem',
          }}>
            <i className="ti ti-plane-tilt" style={{ color: '#fff', fontSize: 24 }} />
          </div>
          <div style={{ color: '#fff', fontSize: '1.4rem' }}>{ACADEMY.name}</div>
          <div style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.8rem', letterSpacing: '2px', textTransform: 'uppercase', marginTop: 4 }}>
            Admission Portal
          </div>
        </div>

        <div style={{
          background: 'rgba(255,255,255,0.05)',
          border: '1px solid rgba(255,255,255,0.1)',
          borderRadius: 'var(--border-radius-xl)',
          padding: '2rem',
        }}>
          {/* Mode toggle */}
          <div style={{ display: 'flex', gap: '0.5rem', marginBottom: '1.5rem' }}>
            {[['login', 'Sign In'], ['register', 'Register']].map(([m, label]) => (
              <button
                key={m}
                onClick={() => switchMode(m)}
                style={{
                  flex: 1, padding: '0.5rem',
                  background: mode === m ? 'var(--blue)' : 'transparent',
                  color:      mode === m ? '#fff' : 'rgba(255,255,255,0.5)',
                  border:     mode === m ? 'none' : '1px solid rgba(255,255,255,0.1)',
                  borderRadius: 'var(--border-radius-sm)',
                }}
              >
                {label}
              </button>
            ))}
          </div>

          {mode === 'forgot' && (
            <div style={{ marginBottom: '1rem', color: 'rgba(255,255,255,0.6)', fontSize: '0.88rem' }}>
              Enter your registered email and we will send a reset link.
            </div>
          )}

          <form onSubmit={handleSubmit}>
            {mode === 'register' && (
              <FormField label="Full Name" icon="ti-user" value={values.name}
                onChange={v => set('name', v)} placeholder="Your full name" dark />
            )}
            <FormField label="Email Address" icon="ti-mail" type="email" value={values.email}
              onChange={v => set('email', v)} placeholder="your@email.com" dark />
            {mode !== 'forgot' && (
              <FormField label="Password" icon="ti-lock" type="password" value={values.password}
                onChange={v => set('password', v)} placeholder="••••••••" dark />
            )}
            {mode === 'register' && (
              <FormField label="Confirm Password" icon="ti-lock-check" type="password" value={values.confirm}
                onChange={v => set('confirm', v)} placeholder="••••••••" dark />
            )}

            {error && (
              <div className="alert alert-error" style={{ marginBottom: '1rem' }}>
                <i className="ti ti-alert-circle" />
                {error}
              </div>
            )}

            <button type="submit" className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', padding: '0.75rem', marginBottom: '1rem' }}>
              {mode === 'login'    ? 'Sign In'
               : mode === 'register' ? 'Create Account'
               : 'Send Reset Link'}
            </button>
          </form>

          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <button onClick={() => setPage('landing')} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.4)', fontSize: '0.85rem' }}>
              <i className="ti ti-arrow-left" style={{ marginRight: 4 }} />Back to Home
            </button>
            {mode === 'login' && (
              <button onClick={() => switchMode('forgot')} style={{ background: 'none', border: 'none', color: 'var(--blue-mid)', fontSize: '0.85rem' }}>
                Forgot password?
              </button>
            )}
            {mode !== 'login' && (
              <button onClick={() => switchMode('login')} style={{ background: 'none', border: 'none', color: 'var(--blue-mid)', fontSize: '0.85rem' }}>
                Back to sign in
              </button>
            )}
          </div>

          {/* Demo credentials hint */}
          {mode === 'login' && (
            <div style={{ marginTop: '1rem', padding: '0.75rem', background: 'rgba(24,95,165,0.15)', borderRadius: 'var(--border-radius-md)', fontSize: '0.8rem', color: 'rgba(255,255,255,0.5)' }}>
              <strong style={{ color: 'rgba(255,255,255,0.7)' }}>Applicant:</strong> demo@flyacademy.com / demo123<br />
              <strong style={{ color: 'rgba(255,255,255,0.7)' }}>Admin:</strong> admin@flyacademy.com / admin123
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
