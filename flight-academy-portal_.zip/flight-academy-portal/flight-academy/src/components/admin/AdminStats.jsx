import { useApp } from '../../context/AppContext';
import StatusBadge from '../common/StatusBadge';

export default function AdminStats() {
  const { applications } = useApp();

  const counts = {
    total:      applications.length,
    accepted:   applications.filter(a => a.status === 'Accepted').length,
    pending:    applications.filter(a => ['Submitted', 'Under Review'].includes(a.status)).length,
    rejected:   applications.filter(a => a.status === 'Rejected').length,
    scheduled:  applications.filter(a => a.testScheduled).length,
  };

  const statCards = [
    { label: 'Total Applications', value: counts.total,     icon: 'ti-file-text',    color: 'var(--blue)'  },
    { label: 'Accepted',           value: counts.accepted,  icon: 'ti-circle-check', color: 'var(--green)' },
    { label: 'Pending Review',     value: counts.pending,   icon: 'ti-clock',        color: 'var(--amber)' },
    { label: 'Rejected',           value: counts.rejected,  icon: 'ti-x',            color: 'var(--red)'   },
  ];

  return (
    <div>
      <h2 style={{ marginBottom: '1.5rem', fontWeight: 400 }}>Dashboard Overview</h2>

      {/* Stat cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '1rem', marginBottom: '2rem' }}>
        {statCards.map((s, i) => (
          <div key={i} className="stat-card" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <div className="stat-label" style={{ marginBottom: 8 }}>{s.label}</div>
              <div className="stat-value" style={{ color: s.color }}>{s.value}</div>
            </div>
            <i className={`ti ${s.icon}`} style={{ fontSize: 28, color: s.color, opacity: 0.25 }} />
          </div>
        ))}
      </div>

      {/* Tests scheduled */}
      <div className="card" style={{ marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
          <h3 style={{ fontWeight: 500, fontSize: '1rem', margin: 0 }}>Tests Scheduled</h3>
          <span className="badge" style={{ background: 'var(--blue-light)', color: 'var(--blue)' }}>{counts.scheduled}</span>
        </div>
        {applications.filter(a => a.testScheduled).length === 0
          ? <div style={{ color: 'var(--gray-600)', fontSize: '0.88rem' }}>No tests scheduled yet.</div>
          : applications.filter(a => a.testScheduled).map(a => (
              <div key={a.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.6rem 0', borderBottom: '1px solid var(--gray-100)', fontSize: '0.88rem', alignItems: 'center' }}>
                <div>
                  <div style={{ fontWeight: 500 }}>{a.name}</div>
                  <div style={{ color: 'var(--gray-600)', fontSize: '0.8rem' }}>{a.testScheduled}</div>
                </div>
                {a.testScore !== null
                  ? <span className="badge" style={{ background: parseInt(a.testScore) >= 60 ? 'var(--green-light)' : 'var(--red-light)', color: parseInt(a.testScore) >= 60 ? 'var(--green)' : 'var(--red)' }}>
                      {a.testScore}/100
                    </span>
                  : <span className="badge" style={{ background: 'var(--gray-100)', color: 'var(--gray-600)' }}>Pending score</span>
                }
              </div>
            ))
        }
      </div>

      {/* Recent applications */}
      <div className="card">
        <h3 style={{ fontWeight: 500, fontSize: '1rem', marginBottom: '1rem' }}>Recent Applications</h3>
        {[...applications].reverse().slice(0, 5).map(a => (
          <div key={a.id} style={{ display: 'flex', justifyContent: 'space-between', padding: '0.75rem 0', borderBottom: '1px solid var(--gray-100)', alignItems: 'center' }}>
            <div>
              <div style={{ fontWeight: 500 }}>{a.name}</div>
              <div style={{ fontSize: '0.8rem', color: 'var(--gray-600)' }}>{a.id} — {a.submittedDate}</div>
            </div>
            <StatusBadge status={a.status} />
          </div>
        ))}
      </div>
    </div>
  );
}
