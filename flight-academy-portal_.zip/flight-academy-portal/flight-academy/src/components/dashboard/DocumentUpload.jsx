import { useRef, useState } from 'react';
import { useApp } from '../../context/AppContext';
import { REQUIRED_DOCS } from '../../data/constants';

export default function DocumentUpload() {
  const { myApplication, uploadDocuments } = useApp();
  // Track uploaded filename per doc index
  const [uploads, setUploads] = useState({});
  const inputRefs = useRef({});

  function handleFileChange(docIndex, e) {
    const file = e.target.files[0];
    if (!file || !myApplication) return;
    setUploads(prev => ({ ...prev, [docIndex]: file.name }));
    uploadDocuments(myApplication.id, [file.name]);
  }

  const allUploaded = REQUIRED_DOCS.every((_, i) => uploads[i]);
  const uploadedCount = Object.keys(uploads).length;

  return (
    <div className="card">
      <h2 style={{ margin: '0 0 0.5rem', fontWeight: 400 }}>Document Upload</h2>
      <p style={{ color: 'var(--gray-600)', marginBottom: '1.5rem', fontSize: '0.9rem' }}>
        Upload each required document separately. Accepted formats: PDF, JPG, PNG (max 5 MB each).
      </p>

      {!myApplication && (
        <div className="alert alert-warning" style={{ marginBottom: '1.5rem' }}>
          <i className="ti ti-info-circle" />
          Please submit your application first before uploading documents.
        </div>
      )}

      {/* Progress bar */}
      {myApplication && (
        <div style={{ marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.82rem', marginBottom: 6 }}>
            <span style={{ color: 'var(--gray-600)' }}>Upload Progress</span>
            <span style={{ fontWeight: 600, color: uploadedCount === REQUIRED_DOCS.length ? 'var(--green)' : 'var(--blue)' }}>
              {uploadedCount} / {REQUIRED_DOCS.length} uploaded
            </span>
          </div>
          <div style={{ height: 6, background: 'var(--gray-200)', borderRadius: 99, overflow: 'hidden' }}>
            <div style={{
              height: '100%',
              width: `${(uploadedCount / REQUIRED_DOCS.length) * 100}%`,
              background: allUploaded ? 'var(--green)' : 'var(--blue)',
              borderRadius: 99,
              transition: 'width 0.3s ease',
            }} />
          </div>
        </div>
      )}

      {/* One row per document */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
        {REQUIRED_DOCS.map((docName, i) => {
          const uploaded = uploads[i];
          return (
            <div key={i} style={{
              display: 'flex', alignItems: 'center', justifyContent: 'space-between',
              padding: '0.9rem 1rem',
              border: `1px solid ${uploaded ? 'var(--green-mid)' : 'var(--gray-200)'}`,
              borderRadius: 'var(--border-radius-md)',
              background: uploaded ? 'var(--green-light)' : '#fff',
              gap: '1rem',
              flexWrap: 'wrap',
            }}>
              {/* Doc name + status */}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, flex: 1, minWidth: 0 }}>
                <div style={{
                  width: 36, height: 36, borderRadius: 8, flexShrink: 0,
                  background: uploaded ? 'var(--green)' : 'var(--blue-light)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                }}>
                  <i className={`ti ${uploaded ? 'ti-circle-check' : 'ti-file-description'}`}
                    style={{ fontSize: 18, color: uploaded ? '#fff' : 'var(--blue)' }} />
                </div>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontWeight: 500, fontSize: '0.9rem', color: 'var(--navy)' }}>{docName}</div>
                  {uploaded
                    ? <div style={{ fontSize: '0.78rem', color: 'var(--green)', marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                        <i className="ti ti-paperclip" style={{ marginRight: 4 }} />{uploaded}
                      </div>
                    : <div style={{ fontSize: '0.78rem', color: 'var(--gray-600)', marginTop: 2 }}>Not uploaded yet</div>
                  }
                </div>
              </div>

              {/* Upload / Re-upload button */}
              <div>
                <input
                  ref={el => inputRefs.current[i] = el}
                  type="file"
                  accept=".pdf,.jpg,.jpeg,.png"
                  onChange={e => handleFileChange(i, e)}
                  style={{ display: 'none' }}
                />
                <button
                  onClick={() => myApplication && inputRefs.current[i]?.click()}
                  disabled={!myApplication}
                  style={{
                    padding: '0.4rem 1rem',
                    background: uploaded ? '#fff' : 'var(--blue)',
                    color: uploaded ? 'var(--green)' : '#fff',
                    border: `1px solid ${uploaded ? 'var(--green-mid)' : 'var(--blue)'}`,
                    borderRadius: 'var(--border-radius-sm)',
                    cursor: myApplication ? 'pointer' : 'not-allowed',
                    fontSize: '0.82rem',
                    fontWeight: 500,
                    display: 'flex', alignItems: 'center', gap: 6,
                    whiteSpace: 'nowrap',
                  }}
                >
                  <i className={`ti ${uploaded ? 'ti-refresh' : 'ti-upload'}`} />
                  {uploaded ? 'Re-upload' : 'Upload'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* All done banner */}
      {allUploaded && (
        <div className="alert alert-success" style={{ marginTop: '1.5rem' }}>
          <i className="ti ti-circle-check" />
          All documents uploaded successfully. Your application is complete.
        </div>
      )}
    </div>
  );
}
