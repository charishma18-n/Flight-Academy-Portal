import { useApp } from '../../context/AppContext';
import StatusBadge from '../common/StatusBadge';
import { COURSES } from '../../data/constants';

export default function OverviewTab({ onTabChange }) {
  const { user, myApplication } = useApp();

  return (
    <div>
      {/* Hero banner */}
      <div style={{
        background: 'linear-gradient(135deg, var(--navy) 0%, var(--blue) 100%)',
        borderRadius: 'var(--border-radius-xl)',
        padding: '2rem',
        marginBottom: '1.5rem',
        color: '#fff',
      }}>
        <div style={{ fontSize: '0.85rem', color: 'rgba(255,255,255,0.5)', marginBottom: 4 }}>Welcome back</div>
        <h2 style={{ color: '#fff', margin: '0 0 0.5rem', fontSize: '1.6rem' }}>{user?.name}</h2>
        <p style={{ color: 'rgba(255,255,255,0.6)', margin: 0, fontSize: '0.9rem' }}>
          {myApplication
            ? `Your application is currently ${myApplication.status}.`
            : 'You have not submitted an application yet. Start your journey today.'}
        </p>
        {!myApplication && (
          <button className="btn" onClick={() => onTabChange('apply')}
            style={{ marginTop: '1rem', background: '#fff', color: 'var(--blue)', fontWeight: 600 }}>
            Start Application
          </button>
        )}
      </div>

      {/* Quick stats */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem', marginBottom: '1.5rem' }}>
        {[
          { icon: 'ti-file-text', label: 'Application', value: myApplication ? myApplication.id : 'Not submitted', color: 'var(--blue)' },
          { icon: 'ti-upload',    label: 'Documents',    value: myApplication ? `${myApplication.documents.length} uploaded` : '0 uploaded', color: 'var(--green)' },
          { icon: 'ti-calendar-event', label: 'Test Date', value: myApplication?.testScheduled || 'Not scheduled', color: 'var(--amber)' },
        ].map((s, i) => (
          <div key={i} className="stat-card">
            <i className={`ti ${s.icon}`} style={{ fontSize: 24, color: s.color, marginBottom: 8, display: 'block' }} />
            <div className="stat-label">{s.label}</div>
            <div style={{ fontWeight: 600, color: 'var(--navy)', fontSize: '0.9rem', marginTop: 4 }}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Notifications */}
      {myApplication?.notifications?.length > 0 && (
        <div className="card" style={{ marginBottom: '1rem' }}>
          <h3 style={{ fontWeight: 500, marginBottom: '1rem', fontSize: '1rem' }}>Recent Notifications</h3>
          {[...myApplication.notifications].reverse().slice(0, 3).map((n, i) => (
            <div key={i} style={{
              padding: '0.6rem 0.75rem',
              borderLeft: '3px solid var(--blue)',
              background: '#f8faff',
              borderRadius: '0 6px 6px 0',
              marginBottom: 8,
              fontSize: '0.88rem',
            }}>
              {n}
            </div>
          ))}
        </div>
      )}

      {/* Courses grid */}
      <div className="card">
        <h3 style={{ fontWeight: 500, marginBottom: '1rem', fontSize: '1rem' }}>Courses Offered</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
          {COURSES.map(c => (
            <div key={c.id} style={{ padding: '0.75rem', border: '1px solid var(--gray-200)', borderRadius: 'var(--border-radius-md)' }}>
              <div style={{ fontWeight: 600, fontSize: '0.88rem', marginBottom: 4 }}>{c.name}</div>
              <div style={{ fontSize: '0.78rem', color: 'var(--gray-600)' }}>{c.duration} &nbsp;|&nbsp; {c.fee}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
