import { ADMIN_TABS, ACADEMY } from '../../data/constants';
import { useApp } from '../../context/AppContext';

export default function AdminSidebar({ activeTab, onTabChange }) {
  const { logout } = useApp();

  return (
    <div style={{ width: 220, flexShrink: 0, background: '#fff', borderRight: '1px solid var(--gray-200)', display: 'flex', flexDirection: 'column' }}>
      {/* Brand */}
      <div style={{ padding: '1.25rem 1.25rem 0.75rem', borderBottom: '1px solid var(--gray-200)' }}>
        <div style={{ fontWeight: 600, fontSize: '0.95rem' }}>{ACADEMY.name}</div>
        <div style={{ fontSize: '0.75rem', color: 'var(--gray-600)', marginTop: 2 }}>Administrator Panel</div>
      </div>

      {/* Nav */}
      <nav style={{ flex: 1, padding: '0.75rem 0' }}>
        {ADMIN_TABS.map(tab => (
          <button
            key={tab.id}
            className={`sidebar-item ${activeTab === tab.id ? 'active' : ''}`}
            onClick={() => onTabChange(tab.id)}
          >
            <i className={`ti ${tab.icon}`} style={{ fontSize: 16 }} />
            {tab.label}
          </button>
        ))}
      </nav>

      {/* Logout at bottom */}
      <div style={{ padding: '1rem', borderTop: '1px solid var(--gray-200)' }}>
        <button
          onClick={logout}
          style={{
            width: '100%', padding: '0.6rem', background: 'var(--gray-50)',
            border: '1px solid var(--gray-200)', borderRadius: 'var(--border-radius-sm)',
            color: 'var(--gray-800)', display: 'flex', alignItems: 'center', gap: 8,
            fontSize: '0.88rem',
          }}
        >
          <i className="ti ti-logout" />Sign Out
        </button>
      </div>
    </div>
  );
}
